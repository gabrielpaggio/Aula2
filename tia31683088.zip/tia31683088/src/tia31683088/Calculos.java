package tia31683088;

public class Calculos {

    public float calc(int[] digitos, int modo) {
        
//        int switchParaModo = 0;
//        Calculos c = new Calculos();
//        digitos = new int[8];
//        digitos[0] = 3;
//        digitos[1] = 1;
//        digitos[2] = 6;
//        digitos[3] = 8;
//        digitos[4] = 3;
//        digitos[5] = 0;
//        digitos[6] = 8;
//        digitos[7] = 8;

        switch (modo) {

            case 1:
                return modo1(digitos);
                
                
            case 2:
                modo2(digitos);
                break;
            case 3:
                modo3(digitos);
                break;

            case 4:
                modo4(digitos);
                break;

            case 5:
                modo5(digitos);
                break;

            case 6:
                modo6(digitos);
                break;

            case 7:
                modo7(digitos);
                break;

            case 8:
                modo8(digitos);
                break;

            case 9:
                modo9(digitos);
                break;

            case 10:
                modo10(digitos);
                break;

            default:

                System.out.println("Este caso não é válido.");
        }
        return 0;
    }

    public int modo1(int[] digitos) {
//        int soma = 0;
//        for (int i = 0; i < 8; i++) {
//            soma += digitos[i];
//        }
        return 0;
    }

    public int modo2(int[] digitos) {
        return 0;
    }

    public int modo3(int[] digitos) {
        return 0;
    }

    public int modo4(int[] digitos) {
        return 0;
    }

    public int modo5(int[] digitos) {
        return 0;
    }

    public int modo6(int[] digitos) {
        return 0;
    }

    public int modo7(int[] digitos) {
        return 0;
    }

    public int modo8(int[] digitos) {
        return 0;
    }

    public int modo9(int[] digitos) {
        return 0;
    }

    public int modo10(int[] digitos) {
        return 0;
    }
}
